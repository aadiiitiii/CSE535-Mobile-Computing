package com.example.covid_symptoms_tracker;

import junit.framework.TestCase;

public class UserDetailsTest extends TestCase {

}